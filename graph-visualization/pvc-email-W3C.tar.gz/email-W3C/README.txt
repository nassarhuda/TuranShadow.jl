Emails from the corpus of crawled W3C mailing lists:
https://tides.umiacs.umd.edu/webtrec/trecent/parsed_w3c_corpus.html

The file email-W3C.txt has three columns:
sender recipient timestamp

The sender and recipient are integer IDs, starting from 1.
Timestamps are in seconds.

The file core-email-W3C.txt contains the IDs of the "core" nodes. These are the
email addresses with w3.org in the domain.

The file addresses-email-W3C.txt maps the integer IDs to email addresses.
