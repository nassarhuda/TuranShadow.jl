Emails from the Enron email dataset derived from William Cohen's dataset at
https://www.cs.cmu.edu/~enron/

The file email-Enron.txt has three columns:
sender recipient timestamp

The sender and recipient are integer IDs, starting from 1.
Timestamps are in seconds.

The file core-email-Enron.txt contains the IDs of the "core" nodes. These
correspond to the individuals whose email inboxes were released as part of the
investigation by the Federal Energy Regulatory Commission.

The file addresses-email-Enron.txt maps the integer IDs to email addresses.
